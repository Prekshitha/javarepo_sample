package com.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;


import org.springframework.stereotype.Repository;

import com.model.Hostel;
import com.model.Ngotable;
import com.model.Sukanya;
import com.model.Training;
import com.model.Users;
import com.model.Workingwomen;

@Repository("myUserDao")
public class UserDaoImpl implements UserDaoIntf
{
	
	@PersistenceContext
	EntityManager em;
	
	public boolean insertUser(Users user) 
	{
		
		boolean result = false;
		try
		{
			System.out.println("Dao is Called");
			
			em.persist(user);
	
			result = true;
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}		
		return result;	
	}
	
	public Users userLogin(Users user)
	{
		  	
			Users f = null;
			try
			{
				f = (Users)em.createQuery("SELECT f FROM Users f WHERE f.username=:username and f.password=:password")
			         .setParameter("username", user.getUsername())
			         .setParameter("password",user.getPassword())
			         .getSingleResult();
			}
			catch(Exception e) 
			{
				System.out.println(e); 
			}
			em.close();

			return f;
	}

	public boolean changePassword(String username, String opwd, String npwd) 
	{

		  boolean flag=false;
		   
		  Query query = em.createQuery("update Users u set u.password=:npwd where u.username=:username and u.password=:opwd");
		  query.setParameter("npwd", npwd);
		  query.setParameter("opwd", opwd);
		  query.setParameter("username", username);
		 
		  int r = query.executeUpdate();
		
		  em.close();
		  if(r>0)
			  flag=true;
		  return flag;
	}

	public boolean enterPassword(String email_id, String contact_number, String password) 
	{
		  boolean flag=false;
		  
		  Query q = em.createQuery("UPDATE Users s SET s.password=:password WHERE s.email_id=:email_id AND s.contact_number=:contact_number");
		 
		  q.setParameter("email_id", email_id);
		  q.setParameter("contact_number", contact_number);
		  q.setParameter("password", password);
		  
		  System.out.println(email_id);
		  System.out.println(password);
		  int r = q.executeUpdate();
		  
		  em.close();
		 
		  if(r>0)
			flag=true;
		  return flag;
	}
	public int checkEmail(String email_id) 
	{
		int result = 0;
		try
		{
			result= (Integer) em.createQuery("SELECT f FROM Users f WHERE f.email_id=:email_id")
		         .setParameter("email_id", email_id)
		         .getSingleResult();
		}
		catch(Exception e) 
		{
			System.out.println(e); 
		}
		em.close();
		return result;
	}

	public boolean insertWorkingwomen(Workingwomen ww) {
		Boolean result=false;
		try{
			
			
			em.persist(ww);
			
			System.out.println("dao is called");
            result=true;
            em.close();
           
			
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		
		return result;
	}

	public List<Workingwomen> getUsers() {
		
		@SuppressWarnings("unchecked")
		List<Workingwomen> list=em.createQuery("SELECT w FROM Workingwomen w where w.status=:status").setParameter("status", "false").getResultList();
		System.out.println("dao is called");
		return list;
	}

	public boolean insertForm(Sukanya sukanya) {
		System.out.println("dao called");
		boolean flag=false;
		try{
			
			em.persist(sukanya);
		
		    em.close();
		   
		    flag=true;
		    System.out.println("Done");
			}
			catch (Exception e){
				System.out.println("Error"+e);
			}
		
		return flag;
	}

	public List<Sukanya> getUser() {
		
		@SuppressWarnings("unchecked")
		List<Sukanya> list= em.createQuery("SELECT u FROM  Sukanya u").getResultList();
		System.out.println("dao is called:"+ list.size());
		return list;
	}

	public boolean insertngo(Ngotable ngo) {
		boolean result=false;

		System.out.println("dao ngo is called");
				try{
					
					em.persist(ngo);
					
		            result=true;
		            em.close();
		         
					
				}
				catch(Exception ee){
					System.out.println(ee.getMessage());
				}
				
				return result;
	}

	public List<Ngotable> getNgo() {
		
		@SuppressWarnings("unchecked")
		List<Ngotable> list=em.createQuery("SELECT n FROM ngo n").getResultList();
		System.out.println("dao is called");
		return list;
	
	}

	public boolean inserttraining(Training training) {
boolean result=false;
		
		try{
		
			em.persist(training);
			
			System.out.println("dao training is called");
            result=true;
            em.close();
          
			
		}
		catch(Exception ee){
			System.out.println(ee.getMessage());
		}
		
		return result;
	}

	public List<Training> gettraining() {
		
		@SuppressWarnings("unchecked")
		List<Training> list=em.createQuery("SELECT t FROM Training t").getResultList();
		System.out.println("dao is called");
		return list;
	
	}

	public boolean insertForm(Hostel hostel) {

		boolean flag=false;
		try{
			
			em.persist(hostel);
			
		    em.close();
		   
		    flag=true;
		    System.out.println("dao called");
		    System.out.println("Done");
			}
			catch (Exception e){
				System.out.println("Error"+e);
			}
		
		return flag;
	}

	public List<Hostel> getUserh() {
		
		@SuppressWarnings("unchecked")
		List<Hostel> list= em.createQuery("SELECT u FROM  Hostel u").getResultList();
		System.out.println("dao is called:"+ list.size());
		return list;
	}

	public int approvedList(int wid) {

		String sql= " Update Workingwomen w set w.status=:status where w.wid=:wid";
		Query query = em.createQuery(sql).setParameter("status","true").setParameter("wid",wid);
		int result = query.executeUpdate();

		System.out.println("dao is called");
		return result;
	}

	public List<Workingwomen> approvedrecords() {
		List<Workingwomen> list=em.createQuery("SELECT w FROM Workingwomen w where w.status=:status").setParameter("status", "true").getResultList();
		System.out.println("dao is called");
		return list;
	}

	
}
