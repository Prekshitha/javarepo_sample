/*package com.controller;

import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.model.Hostel;

import com.service.HostelServiceIntf;

@Controller
public class HostelController {
	
			@Autowired
			HostelServiceIntf HService;
			
			
		@RequestMapping(value="/hostel",method=RequestMethod.GET)
		public String getQueryform(){
			return "hostel";
		}
		@RequestMapping(value="/hostel", method=RequestMethod.POST)
		public ModelAndView insertForm(HttpServletRequest request,HttpServletResponse response) throws ParseException{
		
		
			String hname = request.getParameter("hname");
			String haddress = request.getParameter("haddress");
			int roomcount = Integer.parseInt(request.getParameter("roomcount"));
			
			Hostel hostel = new Hostel();
			hostel.setHname(hname);
			hostel.setHaddress(haddress);
			hostel.setRoomcount(roomcount);
			boolean flag=HService.insertForm(hostel);
			System.out.println("Flag:"+flag);
			ModelAndView mav=new ModelAndView();
			mav.addObject("name",hname);
			if(flag)
				mav.addObject("message is accepted");
			else
				mav.addObject("sorry.........message is not accecepted");
			mav.setViewName("viewhostel");
			return mav;
		}
		
		@RequestMapping(value="/viewhostel",method=RequestMethod.GET)
		public ModelAndView ViewUser(){
			List<Hostel> list=HService.getUserh();
			System.out.println(list.size());
			ModelAndView mav=new ModelAndView("viewhostelrecord");
			mav.addObject("obj",list);
			return  mav;
		}	

}
*/