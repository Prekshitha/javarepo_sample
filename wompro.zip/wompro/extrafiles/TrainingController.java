/*package com.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.model.Hostel;
import com.model.Ngotable;
import com.model.Training;
import com.service.TrainingServiceIntf;

@Controller("trainingController")
public class TrainingController {

	@Autowired
	TrainingServiceIntf trainingService;
	
	
	@RequestMapping(value="/training",method=RequestMethod.GET)
	public ModelAndView maketraining(HttpServletRequest request,HttpServletResponse response) throws ParseException{
		ModelAndView mav=new ModelAndView();
		mav.setViewName("training");
		return mav;
		
	}
	
	@RequestMapping(value="/training",method=RequestMethod.POST)
	public ModelAndView inserttraining(HttpServletRequest request,HttpServletResponse response) throws ParseException{
		
		String tname=request.getParameter("tname");
		String tduration=request.getParameter("tduration");
		String ttype=request.getParameter("ttype");
		SimpleDateFormat formatter=new SimpleDateFormat("yyyy-MM-dd");
		Date sdate=formatter.parse(request.getParameter("sdate")); 
		Date edate=formatter.parse(request.getParameter("edate"));
		Date nbatch=formatter.parse(request.getParameter("nbatch"));
		
		
		Training training = new Training();
		training.setTname(tname);
		training.setTtype(ttype);
		training.setTduration(tduration);
		training.setSdate(sdate);
		training.setEdate(edate);
		training.setNbatch(nbatch);
		
		Ngotable ngotable = new Ngotable();
		ngotable.setNid(22); // write from session
		
		training.setNgo(ngotable);
		
		boolean flag=trainingService.inserttraining(training);
		ModelAndView mav=new ModelAndView();
		mav.addObject("tname",tname);
		if(flag)
			mav.addObject("status","Registration Successful");
		else
			mav.addObject("status","Registration Unsuccessful");
		
		mav.setViewName("NgoRegistered");
		return mav;
		
	}
	@RequestMapping(value="/NgoRegistered",method=RequestMethod.GET)
	public ModelAndView ViewUser(){
		List<Training> list=trainingService.getTraining();
		System.out.println(list.size());
		ModelAndView mav=new ModelAndView("viewtrainingrecord");
		mav.addObject("obj",list);
		return  mav;
	}	

	

}
*/