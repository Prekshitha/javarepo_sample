/*package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.TrainingDaoIntf;
import com.model.Training;

@Service("trainingService")
public class TrainingServiceImpl implements TrainingServiceIntf {

	@Autowired
	TrainingDaoIntf trainingDao;

	public boolean inserttraining(Training training) {
		System.out.println("service is called");
		boolean flag=trainingDao.inserttraining(training);
		return flag;
	
	}

	public List<Training> getTraining() {
		List<Training> list=trainingDao.gettraining();
		return list;
	} 
	
	


}
*/