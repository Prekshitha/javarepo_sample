/*package com.service;

import java.util.List;

import com.model.Training;

public interface TrainingServiceIntf {
	public boolean inserttraining(Training training);
	public List<Training> getTraining();
}
*/