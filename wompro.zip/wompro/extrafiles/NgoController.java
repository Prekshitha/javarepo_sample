/*package com.controller;

import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.model.Ngotable;
import com.service.NgoServiceIntf;

@Controller("ngoController")
	public class NgoController {

		@Autowired
		NgoServiceIntf ngoService;
		
		
		@RequestMapping(value="/xyz",method=RequestMethod.GET)
		public String getNgo(){
			return "Ngo";

		}
		@RequestMapping(value="/ngo",method=RequestMethod.POST)
		public ModelAndView insertngo(HttpServletRequest request,HttpServletResponse response) throws ParseException{
			
			System.out.println("Aaya hu me controller me");
			String nname=request.getParameter("nname");
			String nman=request.getParameter("nman");
			String nloc=request.getParameter("nloc");
			String nobj=request.getParameter("nobj");
			String contact=request.getParameter("contact");
			
			Ngotable ngo= new Ngotable();
			ngo.setNname(nname);
			ngo.setNman(nman);
			ngo.setNloc(nloc);
			ngo.setNobj(nobj);
			ngo.setContact(contact);
			
			System.out.println(nobj);
			boolean flag=ngoService.insertngo(ngo);
			ModelAndView mav=new ModelAndView();
			mav.addObject("nname",nname);
			if(flag)
				mav.addObject("status","Registration Successful");
			else
				mav.addObject("status","Registration Unsuccessful");
			
			if(nobj.equals("training"))
					mav.setViewName("training");
			else
					mav.setViewName("hostel");
				
		
			return mav;
			
			
		
		}

}
*/